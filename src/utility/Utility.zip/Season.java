package utility;

public enum Season {
    SPRING, SUMMER, FALL, WINTER
}
