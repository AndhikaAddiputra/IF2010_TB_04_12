package utility;

public enum Weather {
    RAINY, SUNNY
}
