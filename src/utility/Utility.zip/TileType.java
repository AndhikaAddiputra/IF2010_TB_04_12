package utility;

public enum TileType {
    TILLABLE, TILLED, PLANTED,
    HOUSE, POND, SHIPPING_BIN
}