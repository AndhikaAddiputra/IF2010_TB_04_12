package utility;

public enum RelationshipStatus {
    SINGLE, FIANCE, SPOUSE
}
