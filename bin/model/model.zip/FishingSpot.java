package model;

public interface FishingSpot extends Location {}
