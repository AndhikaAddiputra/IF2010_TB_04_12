package model;

import utility.Season;
import utility.Weather;

public class GameState {
    private Time time;
    private Weather weather;
    private Season season;

    public GameState(Weather weather, Season season) {
        this.weather = weather;
        this.season = season;
        this.time = new Time(0, 1); // Start at 00:01

        Thread timeThread = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(1000); // 1 second real time
                    time = time.addMinutes(5); // 5 minutes game time
                    System.out.println("Current Game Time: " + time);
                } catch (InterruptedException e) {
                    break;
                }
            }
        });
        timeThread.setDaemon(true);
        timeThread.start();
    }

    public Time getTime() { return time; }
    public Weather getWeather() { return weather; }
    public Season getSeason() { return season; }
}
