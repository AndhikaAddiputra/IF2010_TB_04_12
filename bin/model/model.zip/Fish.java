package model;

import utility.Season;
import utility.Weather;

public class Fish extends Item{
    private Season season;
    private Integer availableFrom;
    private Integer availableTo;
    private Weather weather;
    private Location location;
    private String type;
    private Integer price;

    public Fish(String itemName, Set<Season> season, Integer availableFrom, Integer availableTo, Set<Weather> weather, Set<Location> location, String type, Integer price) {
        super(itemName, true);
        this.season = season;
        this.availableFrom = availableFrom;
        this.availableTo = availableTo;
        this.weather = weather;
        this.location = location;
        this.type = type;
        this.price = price;
    }

    public Season getSeason() {
        return season;
    }
    public void setSeason(Season season) {
        this.season = season;
    }
    public Integer getTime() {
        return time;
    }
    public void setTime(Integer time) {
        this.time = time;
    }
    public Weather getWeather() {
        return weather;
    }
    public void setWeather(Weather weather) {
        this.weather = weather;
    }
    public Location getLocation() {
        return location;
    }
    public void setLocation(Location location) {
        this.location = location;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public Integer getPrice() {
        return price;
    }
    public void setPrice(Integer price) {
        this.price = price;
    }
    @Override
    public void useItem() {
        System.out.println("Using fish: " + itemName);
        System.out.println("Season: " + season);
        System.out.println("Time: " + time);
        System.out.println("Weather: " + weather);
        System.out.println("Location: " + location);
    }
    @Override
    public void displayItem() {
        System.out.println("Item: " + itemName);
        System.out.println("Edible: " + (edible ? "Yes" : "No"));
        System.out.println("Season: " + season);
        System.out.println("Time: " + availableFrom + " to " + availableTo);
        System.out.println("Weather: " + weather);
        System.out.println("Location: " + location);
    }
    @Override
    public String toString() {
        return "Fish{" +
                "itemName='" + itemName + '\'' +
                ", edible=" + edible +
                ", season=" + season +
                ", time=" + availableFrom + " to " + availableTo +
                ", weather=" + weather +
                ", location=" + location +
                '}';
    }
}
