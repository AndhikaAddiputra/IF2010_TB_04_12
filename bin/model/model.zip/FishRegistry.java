package model;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import utility.Season;
import utility.Weather;

public class FishRegistry {
    private static final Map<String, Fish> fishMap = new HashMap<>();

    static{
        // Common Fish
        fishMap.put("Bullhead", new Fish(
            "Bullhead",
            Set.of(Season.SPRING, Season.SUMMER, Season.FALL,Season.WINTER), 
            0, 1440,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(MountainLake),
            "Common Fish", 40));

        fishMap.put("Carp", new Fish(
            "Carp",
            Set.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER), 
            0, 1440,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(MountainLake, Pond),
            "Common Fish", 20));

        fishMap.put("Chub", new Fish(
            "Chub",
            Set.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER), 
            0, 1440,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(MountainLake, ForestRiver),
            "Common Fish", 20));

        // Reguler Fish
        fishMap.put("Largemouth Bass", new Fish(
            "Largemouth Bass",
            Set.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER), 
            360, 1080,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(MountainLake),
            "Reguler Fish", 40));

        fishMap.put("Rainbow Trout", new Fish(
            "Rainbow Trout",
            Set.of(Season.SUMMER), 
            360, 1080,
            Set.of(Weather.SUNNY), 
            Set.of(MountainLake, ForestRiver),
            "Reguler Fish", 160));

        fishMap.put("Sturgeon", new Fish(
            "Sturgeon",
            Set.of(Season.SUMMER, Season.WINTER), 
            360, 1080,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(MountainLake),
            "Reguler Fish", 40));

        fishMap.put("Midnight Carp", new Fish(
            "Midnight Carp",
            Set.of(Season.FALL, Season.WINTER), 
            1200, 120,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(MountainLake, Pond),
            "Reguler Fish", 80));

        fishMap.put("Flounder", new Fish(
            "Flounder",
            Set.of(Season.SUMMER, Season.SPRING), 
            360, 1320,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(Ocean), "Reguler Fish", 60));

        fishMap.put("Halibut", new Fish(
            "Halibut",
            Set.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER),
            Set.of(360, 1140), 
            360, 660,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(Ocean), "Reguler Fish", 40));
        
        fishMap.put("Octopus", new Fish(
            "Octopus",
            Set.of(Season.SUMMER), 
            360, 1320,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(Ocean), "Reguler Fish", 120));

        fishMap.put("Pufferfish", new Fish(
            "Pufferfish",
            Set.of(Season.SUMMER), 
            0, 960,
            Set.of(Weather.SUNNY), 
            Set.of(Ocean), "Reguler Fish", 240));

        fishMap.put("Sardine", new Fish(
            "Sardine",
            Set.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER), 
            360, 1080,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(Ocean), "Reguler Fish", 40));

        fishMap.put("Super Cucumber", new Fish(
            "Super Cucumber", 
            Set.of(Season.SUMMER, Season.FALL, Season.WINTER), 
            1080, 120,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(Ocean), "Reguler Fish", 80));

        fishMap.put("Catfish", new Fish(
            "Catfish",
            Set.of(Season.SPRING, Season.SUMMER, Season.FALL), 
            360, 1320,
            Set.of(Weather.RAINY), 
            Set.of(ForestRiver, Pond),
            "Reguler Fish"));

        fishMap.put("Salmon", new Fish(
            "Salmon",
            Set.of(Season.FALL), 
            360, 1080,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(ForestRiver), "Reguler Fish"));

        // Legendry Fish
        fishMap.put("Angler", new Fish(
            "Angler",
            Set.of(Season.FALL), 
            480, 1200,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(Pond), "Legendary Fish"));

        fishMap.put("Crimsonfish", new Fish(
            "Crimsonfish",
            Set.of(Season.SUMMER), 
            480, 1200,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(Ocean), "Legendary Fish"));

        fishMap.put("Glacierfish", new Fish(
            "Glacierfish", 
            Set.of(Season.WINTER), 
            480, 1200,
            Set.of(Weather.SUNNY, Weather.RAINY), 
            Set.of(ForestRiver), "Legendary Fish"));

        fishMap.put("Legend", new Fish(
            "Legend",
            Set.of(Season.SPRING), 
            480, 1200,
            Set.of(Weather.RAINY), 
            Set.of(MountainLake), "Legendary Fish"));
    }

    public static Fish getFish(String fishName) {
        return fishMap.get(fishName);
    }
    public static Set<String> getAllFishNames() {
        return fishMap.keySet();
    }
    public static Set<Fish> getAllFish() {
        return Set.copyOf(fishMap.values());
    }
}
