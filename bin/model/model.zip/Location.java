package model;

public interface Location {
    String getName();
    void visit(Player player);
}
